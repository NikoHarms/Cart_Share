<div class="app_table">
	<table cellspacing="0" cellpadding="0">
		<tr>
			<td>
				<p>Congratulations! You have successfully installed the App.</p>
			</td>
		</tr>
	</table>
</div>
