<div class="app_form">
	<?php echo form_open(site_uri($this->uri->uri_string())); ?>
		<?php echo $this->session->flashdata("shop_error"); ?>
		<?php /* ?>
		<p class="label">
			<?php echo form_label("Facebook App Id", "facebook_app_id"); ?>
			<?php echo form_input( array( "name" => "facebook_app_id" , "class" => "text-input" , "id" => "facebook_app_id" , "required" => "" , "value" => ( isset( $shop_details->facebook_app_id ) ? $shop_details->facebook_app_id : "" ) ) ) ; ?>
		</p>
		<?php */ ?>
		<p class="label">
			<?php echo form_label("Please insert the headline for your pop up box here.", "subject"); ?>
			<?php echo form_input( array( "name" => "subject" , "class" => "text-input" , "id" => "subject" , "required" => "" , "value" => ( isset( $shop_details->subject ) ? $shop_details->subject : "Your special offer!" ) ) ) ; ?>
		</p>
		<p class="label">
			<?php echo form_label("Please insert the message for your pop up box here.", "message"); ?>
			<?php echo form_textarea(array("name"=>"message", "id"=>"message", "required"=>"" , "value" => ( isset( $shop_details->message ) ? $shop_details->message : "Share your cart on Facebook and get a 10% discount code." ))); ?>
		</p>
		<p class="label">
			<?php echo form_label("Please insert your discount code here (You need to create the code under &quot;Discounts&quot; first).", "discount_code"); ?>
			<?php echo form_input( array( "name" => "discount_code" , "class" => "text-input" , "id" => "discount_code" , "required" => "" , "value" => ( isset( $shop_details->discount_code ) ? $shop_details->discount_code : "" ) ) ) ; ?>
		</p>
		<p class="middle">
			<?php echo form_radio( array( "name" => "offer_position" , "id" => "offer_position1" , "value" => "automatically" , "checked" => ( ( empty( $shop_details->offer_position ) || $shop_details->offer_position == "automatically" ) ? true : false ) ) ) ; ?>
			<?php echo form_label("Show pop up offer box automatically after cart page has been opened.", "offer_position1"); ?>
		</p>
		<p class="middle">
			<?php echo form_radio( array( "name" => "offer_position" , "id" => "offer_position2" , "value" => "checkout" , "checked" => ( ( isset( $shop_details->offer_position ) && $shop_details->offer_position == "checkout" ) ? true : false ) ) ) ; ?>
			<?php echo form_label("Show pop up offer box after check out button was clicked.", "offer_position2"); ?>
		</p>
		<p class="middle">
			<?php echo form_radio( array( "name" => "offer_position" , "id" => "offer_position3" , "value" => "deactivate" , "checked" => ( ( isset( $shop_details->offer_position ) && $shop_details->offer_position == "deactivate" ) ? true : false ) ) ) ; ?>
			<?php echo form_label("Deactivate pop up offer box on cart page.", "offer_position3"); ?>
		</p>
		<p><?php echo form_submit(array("value"=>"Save")); ?></p>
	<?php echo form_close(); ?>
</div>