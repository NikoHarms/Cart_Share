<?php defined( "BASEPATH" ) OR exit( "No direct script access allowed" );
header( "Access-Control-Allow-Origin: *" );
class Shopapp extends MY_Controller
{
	public $shop_id	= 0 ;
	public $snippets	= "fb-share" ;
	public function __construct()
	{
		parent::__construct();
		$shop	= $this->input->post( "shop" );
		$shop	= ( $shop )? $shop: $this->input->get( "shop" );
		$this->shop = $shop;
		$page	= $this->uri->segment(2);
		$shop_details	= $this->shopapp_model->get_shop( $shop );
		$login_page	= array( "home" );
		if( empty( $shop_details->status ) && in_array( $page, $login_page ) )
		{
			redirect( site_uri( $this->home ) );
			exit;
		}
		if( $shop_details )
		{
			$this->shop_details	= $shop_details;
			$shop	= $shop_details->shop_name;
			$this->shop_id	= $shop_details->id;
			$access_token	= $shop_details->access_token;
		}
		$this->load->library( "shopifyclient" , array( "shop"  => $shop , "token" => ( empty( $access_token ) ? "" : $access_token ) , "key" => SHOPIFY_API_KEY , "secret" => SHOPIFY_SECRET ) );
		if( $this->session->flashdata( "success" ) )
		{
			$this->data["success"]	= $this->session->flashdata( "success" );
		}
	}
	public function index()
	{
		$shop = $this->shop;
		if( !empty( $shop ) )
		{
			if( preg_match( "/^[a-z0-9\.\-\_]+[.]+[a-z]{2,5}$/" , $shop ) )
			{
				$this->install() ;
			} else {
				$this->session->set_flashdata( "shop_error" , "<p class='error'>Please enter valid shop name</p>" );
				redirect( $this->home );
				exit;
			}
		}
		$this->load->view("index", $this->data);
	}
	public function install()
	{
		$location	= $this->shopifyclient->getAuthorizeUrl( SHOPIFY_SCOPE , site_url( "$this->home/response" ) );
		header( "location: $location" );
		exit;
	}
	function response()
	{
		$code = $this->input->get("code");
		$hmac = $this->input->get("hmac");
		$shop = $this->input->get("shop");
		$timestamp = $this->input->get("timestamp");
		$signature = $this->input->get("signature");
		$access_token	= $this->shopifyclient->getAccessToken($code);
		if(!empty($access_token))
		{
			$shop_id	= isset( $this->shop_details->id )? $this->shop_details->id: 0;
			$this->shopapp_model->add_shop(array( "shop_name" => $shop , "status" => "1" , "access_token" => $access_token ), $shop_id);
		}
		redirect( site_url( "$this->home/installed?hmac=$hmac&shop=$shop&signature=$signature&timestamp=$timestamp" ) );
		exit;
	}
	function installed()
	{
		$webhooks	= $this->shopifyclient->call("GET", "/admin/webhooks.json");
		foreach( $webhooks as $webhook )
		{
			if( $webhook["topic"] == "app/uninstalled" )
			{
				$webhook_id	= $webhook["id"];
			}
		}
		if( empty( $webhook_id ) )
		{
			$this->shopifyclient->call( 'POST', "/admin/webhooks.json", array( "webhook" => array( "topic" => "app/uninstalled", "address" => site_uri("$this->home/uninstalled"), "format" => "json" ) ) );
		} else {
			$this->shopifyclient->call( 'PUT', "/admin/webhooks/$webhook_id.json", array( "webhook" => array( "topic" => "app/uninstalled", "address" => site_uri("$this->home/uninstalled"), "format" => "json" ) ) );
		}
		$themes	= $this->shopifyclient->call("GET", "/admin/themes.json");
		foreach($themes as $theme)
		{
			if($theme["role"]=="main")
			{
				$theme_id	= $theme["id"];
				$asset	= array("asset" => array("key" => "templates/cart.liquid"));
				$cart_liquid	= $this->shopifyclient->call("GET", "/admin/themes/$theme_id/assets.json", $asset);
				$cart	= "{% include '$this->snippets' %}" ;
				if( strpos( $cart_liquid["value"] , $cart ) === false )
				{
					$asset["asset"]["value"]	= $cart . $cart_liquid["value"] ;
					$this->shopifyclient->call('PUT', "/admin/themes/$theme_id/assets.json", $asset);
				}
				$theme_assets	= $this->shopifyclient->call( "GET" , "/admin/themes/$theme_id/assets.json" ) ;
				if( empty( array_search( "snippets/$this->snippets.liquid" , array_column( $theme_assets , "key" ) ) ) )
				{
					$this->shopifyclient->call( 'PUT', "/admin/themes/$theme_id/assets.json", array( "asset" => array( "key" => "snippets/$this->snippets.liquid", "value" => "" ) ) ) ;
				}
				$this->shopifyclient->call('PUT', "/admin/themes/$theme_id/assets.json", array("asset" => array("key" => "assets/fb.png", "src" => base_url("assets/fb.png"))));
			}
		}
		redirect( site_uri( "$this->home/home" ) ); 
		exit;
	}
	function uninstalled()
	{
		$shop_id	= isset( $this->shop_details->id )? $this->shop_details->id: 0;
		$this->shopapp_model->add_shop( array( "status" => "0" ) , $shop_id ) ;
		$this->shopapp_model->delete_shop_details( $shop_id ) ;
	}
	function home()
	{
		redirect( site_uri( "$this->home/features" ) ) ;
		die ;
		$this->data["active_tab"]	= "home";
		$this->load->view("template", $this->data);
	}
	function features()
	{
		$_shop_details	= $this->shopapp_model->get_shop_details( $this->shop_id ) ;
		// $this->print_r( $_shop_details ) ;
		if ($this->input->server("REQUEST_METHOD") === "POST")
		{
			$post	= $this->input->post() ;
			$post["shop_id"]	= $this->shop_id ;
			$this->shopapp_model->save_shop_details( $post , ( empty( $_shop_details->id ) ? 0 : $_shop_details->id ) ) ;
			$themes	= $this->shopifyclient->call("GET", "/admin/themes.json");
			foreach($themes as $theme)
			{
				if($theme["role"]=="main")
				{
					$theme_id	= $theme["id"] ;
					$value	= $this->load->view( "fb-share" , $this->shopapp_model->get_shop_details( $this->shop_id ) , true ) ;
					$this->shopifyclient->call( 'PUT', "/admin/themes/$theme_id/assets.json", array( "asset" => array( "key" => "snippets/$this->snippets.liquid", "value" => $value ) ) ) ;
				}
			}
			redirect( site_uri( "$this->home/features" ) ) ;
			die ;
		}
		$this->data["shop_details"]	= $_shop_details ;
		$this->data["active_tab"]	= "features";
		$this->load->view("template", $this->data);
	}
}
?>