{% if cart.item_count > 0 %}
<style>
	a { cursor: pointer; }
	
	.dbug-popup-checkout{margin:0;}

	.dbug-facebook { background: rgba(0, 0, 0, 0.9) none repeat scroll 0 0; display: none; height: 100%; left: 0; position: fixed; top: 0; width: 100%; z-index: 1; }

	.dbug-popup { background: #ffffff none repeat scroll 0 0; border-radius: 3px; height: auto; left: 20%; padding: 15px; position: absolute; top: 30%; width: 60%; z-index: 1; text-align: center; }

	.dbug-close { background: #ffffff none repeat scroll 0 0; border-radius: 16px; box-shadow: 0 0 7px #000000; padding: 0 8px; position: absolute; right: -11px; top: -13px; }

	.dbug-popup-thanks { font-size: 28px; }

	.dbug-popup-code { color: #999999; }

	.dbug-popup-discount > a { border: 1px dashed #cccccc; font-size: 24px; padding: 8px 28px; }

	.dbug-popup-facebook{ background: #3b5998 none repeat scroll 0 0; color: #ffffff; margin: 0 auto; padding: 15px 22px; position: relative; width: 40%; }

	.dbug-popup-facebook a{ color:#fff; }

	.dbug-popup-facebook a::before { background-attachment: scroll; background-clip: border-box; background-image: url('{{ 'fb.png' | asset_url }}'); background-origin: padding-box; background-position: 0 0; background-repeat: no-repeat; background-size: auto auto; content: ''; height: 100%; left: 20px; position: absolute; top: 11px; width: 100%; }
	


	@media only screen and (max-width: 768px) {
		
		.dbug-popup-facebook{width:56%;}
		
		.dbug-popup-code{font-size:15px;}
		
		
		
	}
	@media only screen and (max-width: 767px){
	.dbug-popup-thanks {font-size: 19px;}
	
	.dbug-popup-facebook{width:100%;}
}
	
	@media only screen and (max-width: 640px){
	 .dbug-popup{top: 12%;}	
		
	}	
	
	@media only screen and (max-width: 479px){
	.dbug-popup{left: 10%;
    padding: 15px;
    position: absolute;
    right: 10%;
    text-align: center;
    width: 80%;}
	.dbug-popup-discount > a {
    border: 1px dashed #cccccc;
    font-size: 24px;
    padding: 8px 4px;}
	}
	
	
	@media only screen and (max-width: 360px){
	 .dbug-popup{top:20%;}	
		
	}
</style>
<div class='dbug-facebook' id='dbug-discount-offer' style='display: <?php echo ( $offer_position == "automatically" ) ? "block" : "none" ?>;'>
	<div class='dbug-popup'>
		<div class='dbug-popup-inner'>
			<p class='dbug-popup-thanks'><?php if( isset( $subject ) ) echo $subject ; ?></p>
			<p class='dbug-popup-code'><?php if( isset( $message ) ) echo $message ; ?></p>
			<p class='dbug-popup-facebook'><a onclick='$(this).closest(".dbug-facebook").hide() ; callFacebook() ;'>Share Facebook</a></p>
			<p class='dbug-popup-checkout'><a onclick='$(this).closest(".dbug-facebook").hide() ;' style='color:#808080;'>No Thanks</a></p>
		</div>
	</div>
</div>
<div class='dbug-facebook' id='dbug-discount-popup'>
	<div class='dbug-popup'>
		<a class='dbug-close' onclick='$(this).closest(".dbug-facebook").hide()'>X</a>
		<div class='dbug-popup-inner'>
			<p class='dbug-popup-thanks'>THANK YOU! THIS IS YOUR DISCOUNT CODE:</p>
			<p class='dbug-popup-code'>Please use this discount code when checking out.</p>
			<p class='dbug-popup-discount'><a><?php if( isset( $discount_code ) ) echo $discount_code ; ?></a></p>
		</div>
	</div>
</div>
<a class='automatically_popup'></a>
{{ 'https://connect.facebook.net/en_US/all.js' | script_tag }}
<script>
	function callFacebook()
	{
		{% for item in cart.items %}
		fb_window = window.open( 'https://www.facebook.com/sharer/sharer.php?u={{shop.secure_url}}{{item.url}}&picture=https:{{ item | img_url : "original" }}' , 'popupWindow' , 'width=600,height=400,scrollbars=yes' ) ;
		timer = setInterval(function() { if( fb_window.closed ) { $( '#dbug-discount-popup' ).show() ; clearInterval( timer ) ; } } , 1000 ) ;
		{% break %}
		{% endfor %}
	}
	function fun_checkout()
	{
		$( '.checkout' ).click() ;
	}
	<?php
	if( $offer_position == "checkout" ) {
		?>
		$( document ).ready( function() {
			checkout	= false ;
			$( '.checkout' ).click( function() {
				if( checkout === false )
				{
					checkout	= true ;
					$('#dbug-discount-offer').show() ;
					return false ;
				}
			} ) ;
			return true ;
		} ) ;
		<?php
	}
	?>
</script>
{% endif %}