<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class MY_Controller extends CI_Controller
{
	public $data	= array();
	public function __construct()
	{
		parent::__construct();
		$home	= strtolower( get_class( $this ) ) ;
		$this->home	= $home ;
		$this->data["home"]	= $home ;
	}
	public function print_r($array)
	{
		echo "<pre>" . print_r($array, true) . "</pre>";
	}
}
?>